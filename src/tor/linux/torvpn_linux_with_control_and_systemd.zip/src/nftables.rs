use anyhow::{Result};
use tokio::process::Command;
use crate::config::Config;

pub async fn apply_rules(cfg: &Config, _state_dir: &std::path::Path) -> Result<()> {
    let tun = &cfg.tun.interface;
    let dns_port = cfg.tor.dns_port;
    let trans_port = cfg.tor.trans_port;

    // Build nftables rules depending on mode
    let rules = if cfg.net.mode == "transparent" {
        format!(r#"
flush ruleset
table inet torvpn {{
  chains {{
    output {{
      type filter hook output priority 0; policy drop;
      meta oif "lo" accept
      ip daddr 127.0.0.1 tcp dport {{ {dns_port}, 9050, 9051, {trans_port} }} accept
      udp dport 53 drop
    }}
    prerouting {{
      type nat hook prerouting priority -100;
      # Redirect all TCP to Tor TransPort, exclude local and tor loopback
      tcp dport != {trans_port} redirect to :{trans_port}
    }}
    output_nat {{
      type nat hook output priority -100;
      # Local-originated TCP gets redirected too (covers localhost-originating apps)
      ip daddr != 127.0.0.1 tcp dport != {trans_port} redirect to :{trans_port}
      # Redirect DNS to Tor DNSPort
      udp dport 53 redirect to :{dns_port}
    }}
  }}
}}
"#)
    } else {
        format!(r#"
flush ruleset
table inet torvpn {{
  chains {{
    output {{
      type filter hook output priority 0; policy drop;
      oifname "{tun}" accept
      meta oif "lo" accept
      ip daddr 127.0.0.1 tcp dport {{ {dns_port}, 9050, 9051, 9040 }} accept
      udp dport 53 drop
    }}
  }}
}}
"#)
    };

    Command::new("sh").arg("-lc").arg(format!("nft -f - <<'NFT'\n{}\nNFT", rules)).status().await?;
    Ok(())
}" accept
      meta oif "lo" accept
      # Allow Tor process traffic identified by owner match is complex in nft;
      # For MVP we allow localhost to reach Tor ports.
      ip daddr 127.0.0.1 tcp dport {{ {dns_port}, 9050, 9051, {transport_port} }} accept
      udp dport 53 drop
    }}
  }}
}}
"#);

    Command::new("sh").arg("-lc").arg(format!("nft -f - <<'NFT'\n{}\nNFT", rules)).status().await?;
    Ok(())
}

pub async fn teardown_rules() -> Result<()> {
    Command::new("sh").arg("-lc").arg("nft flush ruleset").status().await?;
    Ok(())
}

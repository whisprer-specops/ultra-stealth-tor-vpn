#!/usr/bin/env bash
set -euo pipefail
BIN="${1:-./target/release/torvpn}"
PROFILE="${2:-profiles/default.toml}"
SYSTEMD="/etc/systemd/system/torvpn.service"

if [[ ! -x "$BIN" ]]; then
  echo "Build binary first: cargo build --release"; exit 1;
fi

sudo install -Dm755 "$BIN" /usr/local/bin/torvpn
sudo install -Dm644 "$PROFILE" /etc/torvpn/profile.toml
sudo install -Dm644 systemd/torvpn.service "$SYSTEMD"

sudo systemctl daemon-reload
sudo systemctl enable torvpn
sudo systemctl start torvpn

echo "[+] torvpn installed and started. Unit: $SYSTEMD"

#!/usr/bin/env bash
set -euo pipefail
TUN="${1:-tun0}"
if ip link show "$TUN" >/dev/null 2>&1; then
  ip link set "$TUN" down || true
  ip tuntap del dev "$TUN" mode tun || true
  echo "[+] TUN $TUN removed"
else
  echo "[=] TUN $TUN not present"
fi

#!/usr/bin/env bash
set -euo pipefail
nft flush ruleset
echo "[+] nftables rules flushed"

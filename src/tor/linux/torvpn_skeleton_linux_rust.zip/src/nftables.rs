use anyhow::{Result};
use tokio::process::Command;
use crate::config::Config;

pub async fn apply_rules(cfg: &Config, _state_dir: &std::path::Path) -> Result<()> {
    // Fail-closed: drop everything except loopback, TUN interface, and tor user traffic.
    // Simpler MVP: block DNS leaks and force traffic via TUN. Advanced sets can be added later.
    let tun = &cfg.tun.interface;
    let dns_port = cfg.tor.dns_port;
    let transport_port = 9040; // reserved if using TransPort later

    let rules = format!(r#"
flush ruleset
table inet torvpn {{
  chains {{
    output {{
      type filter hook output priority 0; policy drop;
      oifname "{tun}" accept
      meta oif "lo" accept
      # Allow Tor process traffic identified by owner match is complex in nft;
      # For MVP we allow localhost to reach Tor ports.
      ip daddr 127.0.0.1 tcp dport {{ {dns_port}, 9050, 9051, {transport_port} }} accept
      udp dport 53 drop
    }}
  }}
}}
"#);

    Command::new("sh").arg("-lc").arg(format!("nft -f - <<'NFT'\n{}\nNFT", rules)).status().await?;
    Ok(())
}

pub async fn teardown_rules() -> Result<()> {
    Command::new("sh").arg("-lc").arg("nft flush ruleset").status().await?;
    Ok(())
}

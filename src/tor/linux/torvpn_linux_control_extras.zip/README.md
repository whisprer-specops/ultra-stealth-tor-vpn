# torvpn (Linux)



## Local HTTP control
If `[status].enabled = true`, an HTTP server runs on `listen` (default `127.0.0.1:8787`).

- `GET /status` → JSON snapshot
- `POST /control/newnym` → rotate Tor circuits

Auth: a token is generated on first start and stored at `~/.local/share/torvpn/api_token`.
Send it as a header:
```
curl -s -X POST http://127.0.0.1:8787/control/newnym \
  -H "X-TorVPN-Token: $(cat ~/.local/share/torvpn/api_token)"
```


### Control API
```
# NEWNYM
curl -s -X POST http://127.0.0.1:8787/control/newnym \
  -H "X-TorVPN-Token: $(cat ~/.local/share/torvpn/api_token)"

# Proxy rotate
curl -s -X POST "http://127.0.0.1:8787/control/proxynext" \
  -H "X-TorVPN-Token: $(cat ~/.local/share/torvpn/api_token)"

# Set exits (comma-separated cc) or clear with cc=
curl -s -X POST "http://127.0.0.1:8787/control/exitset?cc=us,de" \
  -H "X-TorVPN-Token: $(cat ~/.local/share/torvpn/api_token)"
```

#!/usr/bin/env bash
set -euo pipefail
TUN="${1:-tun0}"
CIDR="${2:-10.111.0.1/30}"
ip tuntap add dev "$TUN" mode tun
ip addr add "$CIDR" dev "$TUN"
ip link set "$TUN" up
echo "[+] TUN $TUN up at $CIDR"

#!/usr/bin/env bash
set -euo pipefail
nft -f - <<'NFT'
flush ruleset
table inet torvpn {
  chains {
    output {
      type filter hook output priority 0; policy drop;
      oifname "tun0" accept
      meta oif "lo" accept
      ip daddr 127.0.0.1 tcp dport { 5353, 9050, 9051, 9040 } accept
      udp dport 53 drop
    }
  }
}
NFT
echo "[+] nftables rules applied"

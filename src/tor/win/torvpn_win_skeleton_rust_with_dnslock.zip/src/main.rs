//! torvpn_win: Windows MVP skeleton – manages Tor and external tun2socks (Wintun), with firewall kill-switch.
//! - tor_manager: generates torrc from profile, spawns tor.exe, monitors bootstrap via stdout.
//! - tun2socks_manager: spawns external tun2socks for Windows, device "wintun://<name>"
//! - firewall: applies strict outbound policy allowing only Wintun interface and Tor process
//! - CLI: start/stop/status --profile <file>
//!
//! Requirements on system:
//!   - tor.exe in PATH (or specify by PATH/installation)
//!   - tun2socks.exe in PATH (build that supports Wintun; includes wintun.dll)
//!   - PowerShell available (for firewall scripts)
//!
//! This is privacy tooling for legitimate use only.

mod tor_manager;
mod tun2socks_manager;
mod firewall;
mod config;
mod nrpt;

use clap::{Parser, Subcommand};
use anyhow::{Result, bail};
use std::path::PathBuf;
use tokio::{fs, process::Command};
use dirs::home_dir;

#[derive(Parser, Debug)]
#[command(name="torvpn-win", version, about="Tor-routed VPN (Windows MVP)")]
struct Cli {
    /// Profile TOML path (overrides built-in profiles)
    #[arg(long)]
    profile: Option<PathBuf>,

    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand, Debug)]
enum Cmd {
    /// Start Tor + tun2socks + firewall lock
    Start,
    /// Stop all components and restore firewall
    Stop,
    /// Show status (basic)
    Status,
}

#[tokio::main]
async fn main() -> Result<()> {
    let cli = Cli::parse();
    let state_dir = default_state_dir()?;
    fs::create_dir_all(&state_dir).await?;

    let cfg = config::load_or_default(cli.profile.as_deref()).await?;
    match cli.cmd {
        Cmd::Start => start(cfg, &state_dir).await?,
        Cmd::Stop => stop(&state_dir).await?,
        Cmd::Status => status(&state_dir).await?,
    }
    Ok(())
}

fn default_state_dir() -> Result<PathBuf> {
    let mut p = home_dir().ok_or_else(|| anyhow::anyhow!("no home dir"))?;
    p.push("AppData/Local/torvpn");
    Ok(p)
}

async fn start(cfg: config::Config, state_dir: &PathBuf) -> Result<()> {
    // 1) Apply firewall policy (fail-closed ASAP). We pass adapter hint to PS script.
    firewall::apply_rules(&cfg).await?;

    // 2) DNS lock (NRPT + firewall DNS blocks)
    nrpt::apply_dns_lock(&cfg).await?;

    // 3) Start Tor
    let tor = tor_manager::TorInstance::start(&cfg, state_dir).await?;

    // 3) Start tun2socks (creates/uses Wintun adapter)
    let t2s = tun2socks_manager::Tun2Socks::start(&cfg).await?;

    // Save PIDs
    let pid_path = state_dir.join("pids.json");
    let pids = serde_json::json!({
        "tor": tor.pid(),
        "tun2socks": t2s.pid(),
    });
    tokio::fs::write(&pid_path, serde_json::to_vec_pretty(&pids)?).await?;

    println!("torvpn-win: started (Tor PID {}, tun2socks PID {})", tor.pid(), t2s.pid());
    Ok(())
}

async fn stop(state_dir: &PathBuf) -> Result<()> {
    // Read PIDs if present
    let pid_path = state_dir.join("pids.json");
    if let Ok(bytes) = tokio::fs::read(&pid_path).await {
        if let Ok(val) = serde_json::from_slice::<serde_json::Value>(&bytes) {
            if let Some(pid) = val.get("tun2socks").and_then(|v| v.as_i64()) {
                let _ = Command::new("taskkill").args(["/PID", &pid.to_string(), "/T", "/F"]).status().await;
            }
            if let Some(pid) = val.get("tor").and_then(|v| v.as_i64()) {
                let _ = Command::new("taskkill").args(["/PID", &pid.to_string(), "/T", "/F"]).status().await;
            }
        }
        let _ = tokio::fs::remove_file(&pid_path).await;
    }

    // 1) Teardown DNS lock
    nrpt::teardown_dns_lock().await?;

    // 2) Teardown firewall
    firewall::teardown_rules().await?;

    println!("torvpn-win: stopped");
    Ok(())
}

async fn status(state_dir: &PathBuf) -> Result<()> {
    let pid_path = state_dir.join("pids.json");
    if let Ok(bytes) = tokio::fs::read(&pid_path).await {
        if let Ok(val) = serde_json::from_slice::<serde_json::Value>(&bytes) {
            println!("{}", serde_json::to_string_pretty(&val)?);
            return Ok(());
        }
    }
    println!("not running");
    Ok(())
}

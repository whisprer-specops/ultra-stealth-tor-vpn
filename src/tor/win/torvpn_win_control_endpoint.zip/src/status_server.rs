use anyhow::Result;
use tokio::net::{TcpListener, TcpStream};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use serde_json::json;
use crate::config::Config;
use std::path::Path;
use tokio::fs;

pub async fn run(cfg: Config, state_dir: std::path::PathBuf) -> Result<()> {
    if !cfg.status.enabled { return Ok(()); }
    let addr = cfg.status.listen.clone();
    let listener = TcpListener::bind(&addr).await?;
    tokio::spawn(async move {
        loop {
            match listener.accept().await {
                Ok((sock, _)) => { let _ = handle(sock, &cfg, &state_dir).await; }
                Err(_) => break,
            }
        }
    });
    Ok(())
}

async fn handle(mut sock: TcpStream, cfg: &Config, state_dir: &Path) -> Result<()> {
    let mut buf = vec![0u8; 1024];
    let n = sock.read(&mut buf).await?;
    let req = String::from_utf8_lossy(&buf[..n]);
    let path = req.lines().next().unwrap_or("GET / HTTP/1.1").split_whitespace().nth(1).unwrap_or("/");
    if path != "/status" {
        respond(&mut sock, 404, r#"{"error":"not found"}"#).await?; return Ok(());
    }

    let st_path = state_dir.join("hop_state.json");
    let (idx, next_epoch_ms) = if let Ok(b) = fs::read(&st_path).await {
        if let Ok(v) = serde_json::from_slice::<serde_json::Value>(&b) {
            (v.get("idx").and_then(|x| x.as_u64()).unwrap_or(0) as usize,
             v.get("next_epoch_ms").and_then(|x| x.as_u64()).unwrap_or(0))
        } else { (0, 0) }
    } else { (0, 0) };
    let total = cfg.hop.sequence.len();
    let now_ms = now_ms();
    let remaining = if next_epoch_ms > now_ms { (next_epoch_ms - now_ms) / 1000 } else { 0 };
    let hop_item = cfg.hop.sequence.get(idx).cloned();

    let exit_ip = match get_exit_ip_via_socks(cfg.tor.socks_port).await {
        Ok(s) => Some(s),
        Err(_) => None,
    };

    let body = json!({
        "current_index": idx,
        "total": total,
        "seconds_remaining": remaining,
        "next_epoch_ms": next_epoch_ms,
        "current_hop": hop_item,
        "tor": { "socks_port": cfg.tor.socks_port, "dns_port": cfg.tor.dns_port, "control_port": cfg.tor.control_port },
        "exit_ip": exit_ip,
    }).to_string();

    respond(&mut sock, 200, &body).await?;
    Ok(())
}

async fn respond(sock: &mut TcpStream, code: u16, body: &str) -> Result<()> {
    let status = match code { 200 => "OK", 404 => "Not Found", _ => "OK" };
    let resp = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
        code, status, body.len(), body
    );
    sock.write_all(resp.as_bytes()).await?;
    Ok(())
}

fn now_ms() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() as u64
}

async fn get_exit_ip_via_socks(socks_port: u16) -> Result<String> {
    use tokio::net::TcpStream;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    let mut s = TcpStream::connect(("127.0.0.1", socks_port)).await?;
    s.write_all(&[0x05, 0x01, 0x00]).await?;
    let mut resp = [0u8;2]; s.read_exact(&mut resp).await?;
    if resp != [0x05, 0x00] { anyhow::bail!("socks auth failed"); }
    let host = "api.ipify.org";
    let port = 80u16;
    let hb = host.as_bytes();
    let mut req = Vec::with_capacity(7 + hb.len());
    req.extend_from_slice(&[0x05, 0x01, 0x00, 0x03, hb.len() as u8]);
    req.extend_from_slice(hb);
    req.extend_from_slice(&[(port >> 8) as u8, (port & 0xff) as u8]);
    s.write_all(&req).await?;
    let mut hdr = [0u8;4]; s.read_exact(&mut hdr).await?;
    if hdr[1] != 0x00 { anyhow::bail!("socks connect failed"); }
    match hdr[3] {
        0x01 => { let mut skip=[0u8;6]; s.read_exact(&mut skip).await?; }
        0x03 => { let mut len=[0u8;1]; s.read_exact(&mut len).await?; let mut skip=vec![0u8; len[0] as usize + 2]; s.read_exact(&mut skip).await?; }
        0x04 => { let mut skip=[0u8;18]; s.read_exact(&mut skip).await?; }
        _ => {}
    }
    let get = "GET /?format=text HTTP/1.1\r\nHost: api.ipify.org\r\nConnection: close\r\n\r\n";
    s.write_all(get.as_bytes()).await?;
    let mut buf = Vec::new(); let mut tmp = [0u8;1024];
    loop { match s.read(&mut tmp).await { Ok(0) => break, Ok(n) => buf.extend_from_slice(&tmp[..n]), Err(_) => break } }
    let body = String::from_utf8_lossy(&buf);
    if let Some(idx) = body.rfind("\r\n\r\n") {
        let ip = body[idx+4..].trim(); return Ok(ip.to_string());
    }
    anyhow::bail!("no ip in response")
}

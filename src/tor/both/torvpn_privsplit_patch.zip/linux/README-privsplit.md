# Linux privilege split
- Service runs as **DynamicUser** with minimal caps (NET_ADMIN, BIND_SERVICE) and tight systemd sandboxing.
- State dir: `/var/lib/torvpn` (via StateDirectory). Override with `TORVPN_STATE_DIR`.

## Install
```
unzip torvpn_privsplit_patch.zip -d ./patch
cp -r patch/linux/packaging ./packaging
cp -r patch/linux/scripts ./scripts
python3 patch/linux/patch_state_dir_env.py
sudo ./scripts/install-priv-linux.sh ./target/release/torvpn /etc/torvpn/profiles /var/lib/torvpn
```

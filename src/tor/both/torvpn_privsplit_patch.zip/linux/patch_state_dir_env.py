#!/usr/bin/env python3
from pathlib import Path
p = Path("src/main.rs")
t = p.read_text()
if "state_dir_from_env" not in t:
    t = t.replace(
        "async fn daemon(cfg: config::Config, state_dir: &std::path::Path) -> anyhow::Result<()> {",
        "fn state_dir_from_env() -> std::path::PathBuf {\n    if let Ok(p) = std::env::var(\"TORVPN_STATE_DIR\") { return std::path::PathBuf::from(p); }\n    crate::dirs::default_state_dir()\n}\n\nasync fn daemon(cfg: config::Config, state_dir: &std::path::Path) -> anyhow::Result<()> {"
    )
    t = t.replace("let state_dir = crate::dirs::default_state_dir();", "let state_dir = state_dir_from_env();")
    p.write_text(t)
print("[✓] Patched main.rs to honor TORVPN_STATE_DIR")

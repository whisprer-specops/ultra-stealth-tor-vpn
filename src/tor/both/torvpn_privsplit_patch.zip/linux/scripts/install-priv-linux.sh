#!/usr/bin/env bash
set -euo pipefail
BIN=${1:-"./target/release/torvpn"}
PROFILE_DIR=${2:-"/etc/torvpn/profiles"}
STATE_DIR=${3:-"/var/lib/torvpn"}
install -Dm0755 "$BIN" /usr/local/bin/torvpn
install -d -m0755 "${PROFILE_DIR}"
if [ -d "./profiles" ]; then cp -n ./profiles/*.toml "${PROFILE_DIR}" || true; fi
install -d -m0750 "${STATE_DIR}"
chown root:root "${STATE_DIR}"
install -Dm0644 linux/packaging/systemd/torvpn.service /etc/systemd/system/torvpn.service
systemctl daemon-reload
setcap cap_net_admin,cap_net_bind_service+ep /usr/local/bin/torvpn || true
systemctl enable torvpn
systemctl restart torvpn
echo "[✓] torvpn service installed and running with DynamicUser + caps"

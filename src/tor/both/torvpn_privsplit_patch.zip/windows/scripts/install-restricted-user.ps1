param([string]$UserName = "torvpn-run",[string]$ServiceName = "TorVPN")
$prog = "$env:ProgramData\torvpn"
$newPass = -join ((48..57 + 65..90 + 97..122) | Get-Random -Count 24 | ForEach-Object {[char]$_})
$sec = ConvertTo-SecureString -String $newPass -AsPlainText -Force
if (-not (Get-LocalUser -Name $UserName -ErrorAction SilentlyContinue)) {
  New-LocalUser -Name $UserName -Password $sec -AccountNeverExpires -PasswordNeverExpires -UserMayNotChangePassword | Out-Null
}
secedit /export /cfg $env:TEMP\secpol.cfg | Out-Null
(gc $env:TEMP\secpol.cfg) -replace 'SeServiceLogonRight = (.*)', $($matches[0] + ",$env:COMPUTERNAME\$UserName") | sc $env:TEMP\secpol2.cfg
secedit /import /cfg $env:TEMP\secpol2.cfg /db secedit.sdb | Out-Null
secedit /configure /db secedit.sdb | Out-Null
New-Item -ItemType Directory -Path $prog -Force | Out-Null
$bytes = [System.Text.Encoding]::UTF8.GetBytes($newPass)
$prot = [System.Security.Cryptography.ProtectedData]::Protect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
$blob = [System.Convert]::ToBase64String($prot)
@{ username = ".\$UserName"; domain = "."; secret_dpapi_b64 = $blob } | ConvertTo-Json | Set-Content -Encoding UTF8 "$prog\runas.json"
icacls "$prog\runas.json" /inheritance:r /grant:r "SYSTEM:(F)" "Administrators:(F)" | Out-Null
Write-Host "[✓] Created $UserName and DPAPI-protected creds at $prog\runas.json"

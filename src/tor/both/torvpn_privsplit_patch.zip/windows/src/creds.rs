use anyhow::Result;
use tokio::fs;
use serde::Deserialize;
use windows::Win32::Security::Cryptography::{CryptUnprotectData, CRYPT_INTEGER_BLOB};

#[derive(Deserialize, Clone)]
pub struct StoredCreds { pub username: String, pub domain: String, pub secret_dpapi_b64: String }

pub async fn load_creds(dir: &std::path::Path) -> Result<(String, String, String)> {
    let p = dir.join("runas.json");
    let b = fs::read(&p).await?;
    let sc: StoredCreds = serde_json::from_slice(&b)?;
    let blob = base64::decode(sc.secret_dpapi_b64)?;
    let mut data_in = CRYPT_INTEGER_BLOB { cbData: blob.len() as u32, pbData: blob.as_ptr() as *mut u8 };
    let mut data_out = CRYPT_INTEGER_BLOB { cbData: 0, pbData: std::ptr::null_mut() };
    unsafe {
        let ok = CryptUnprotectData(&mut data_in, None, None, None, None, 0, &mut data_out).as_bool();
        if !ok { anyhow::bail!("DPAPI decrypt failed"); }
        let s = std::slice::from_raw_parts(data_out.pbData, data_out.cbData as usize).to_vec();
        let pass = String::from_utf8(s)?;
        Ok((sc.username, sc.domain, pass))
    }
}

use anyhow::Result;
use std::path::Path;
use windows::Win32::Security::{LogonUserW, LOGON32_LOGON_SERVICE, LOGON32_PROVIDER_DEFAULT};
use windows::Win32::Foundation::{CloseHandle, HANDLE};
use windows::Win32::System::Threading::{CreateProcessAsUserW, PROCESS_INFORMATION, STARTUPINFOW, CREATE_UNICODE_ENVIRONMENT};
use windows::core::PCWSTR;
use widestring::U16CString;

pub struct RunAsCreds { pub username: String, pub password: String, pub domain: String }

pub fn spawn_as(creds: &RunAsCreds, cmdline: &str, workdir: &Path) -> Result<()> {
    unsafe {
        let mut h_user: HANDLE = HANDLE(0);
        let user = U16CString::from_str(&creds.username).unwrap();
        let domain = U16CString::from_str(&creds.domain).unwrap();
        let pass = U16CString::from_str(&creds.password).unwrap();
        let ok = LogonUserW(PCWSTR(user.as_ptr()), PCWSTR(domain.as_ptr()), PCWSTR(pass.as_ptr()),
                            LOGON32_LOGON_SERVICE, LOGON32_PROVIDER_DEFAULT, &mut h_user).as_bool();
        if !ok { anyhow::bail!("LogonUserW failed"); }
        let mut si: STARTUPINFOW = std::mem::zeroed(); si.cb = std::mem::size_of::<STARTUPINFOW>() as u32;
        let mut pi: PROCESS_INFORMATION = std::mem::zeroed();
        let cmd = U16CString::from_str(cmdline).unwrap();
        let wd = U16CString::from_str(&workdir.to_string_lossy()).unwrap();
        let ok = CreateProcessAsUserW(h_user, None, PCWSTR(cmd.as_ptr()), None, None, false,
                                      CREATE_UNICODE_ENVIRONMENT, None, PCWSTR(wd.as_ptr()), &si, &mut pi).as_bool();
        let _ = CloseHandle(h_user);
        if !ok { anyhow::bail!("CreateProcessAsUserW failed"); }
    }
    Ok(())
}

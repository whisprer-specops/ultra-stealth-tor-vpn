#!/usr/bin/env python3
from pathlib import Path
c = Path("Cargo.toml")
t = c.read_text()
if "windows =" not in t:
    t = t.replace("[dependencies]", "[dependencies]\nwidestring = \"1.0\"\nwindows = { version = \"0.54\", features = [\"Win32_Foundation\",\"Win32_Security\",\"Win32_System_Threading\",\"Win32_Security_Cryptography\"] }")
c.write_text(t)
print("[✓] Ensured windows + widestring crates are present")

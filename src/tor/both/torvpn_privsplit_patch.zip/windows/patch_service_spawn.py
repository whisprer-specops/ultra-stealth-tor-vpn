#!/usr/bin/env python3
from pathlib import Path
svc = Path("src/service.rs")
t = svc.read_text()
if "mod runas;" not in t:
    t = t.replace("use crate::tor_control::TorControl;", "use crate::tor_control::TorControl;\nmod runas;\nmod creds;")
if "runas.json" not in t:
    t = t.replace(
        "let tor = start_tor(&cfg, &state_dir).await?;",
        "let runas_file = state_dir.join(\"runas.json\");\n        let tor = if runas_file.exists() {\n            let (u,d,p) = creds::load_creds(&state_dir).await?;\n            let exe = tor_bin(); let args = tor_args(&cfg, &state_dir);\n            let cmd = format!(\"\\\"{}\\\" {}\", exe.display(), args.join(\" \"));\n            runas::spawn_as(&runas::RunAsCreds{username:u,domain:d,password:p}, &cmd, &state_dir)?; None\n        } else { start_tor(&cfg, &state_dir).await? };"
    )
    t = t.replace(
        "let t2s = start_tun2socks(&cfg, &state_dir).await?;",
        "let t2s = if runas_file.exists() {\n            let (u,d,p) = creds::load_creds(&state_dir).await?;\n            let exe = tun2socks_bin(); let args = tun2socks_args(&cfg, &state_dir);\n            let cmd = format!(\"\\\"{}\\\" {}\", exe.display(), args.join(\" \"));\n            runas::spawn_as(&runas::RunAsCreds{username:u,domain:d,password:p}, &cmd, &state_dir)?; None\n        } else { start_tun2socks(&cfg, &state_dir).await? };"
    )
svc.write_text(t)
print("[✓] Patched service.rs to spawn Tor/tun2socks as restricted user when runas.json exists")

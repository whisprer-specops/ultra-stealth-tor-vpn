# Windows privilege split
- Service remains **LocalSystem** for firewall/NRPT/adapter duties.
- **Tor** and **tun2socks** spawn under restricted user `torvpn-run` using CreateProcessAsUser, when ProgramData creds exist.

## Install
```
unzip torvpn_privsplit_patch.zip -d .\patch
copy .\patch\windows\src\runas.rs .\src\runas.rs
copy .\patch\windows\src\creds.rs .\src\creds.rs
python .\patch\windows\patch_service_spawn.py
python .\patch\windows\patch_cargo_deps.py

# Build and install service as usual, then run:
powershell -ExecutionPolicy Bypass -File .\patch\windows\scripts\install-restricted-user.ps1
# Restart the service afterwards
sc.exe stop TorVPN & sc.exe start TorVPN
```

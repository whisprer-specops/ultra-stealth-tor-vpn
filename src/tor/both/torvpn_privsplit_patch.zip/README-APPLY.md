# Privilege Split Patch Bundle
This bundle adds Linux systemd sandbox + caps and Windows restricted child-process execution.

## Linux
1) Extract into your project root.
2) Run `python3 linux/patch_state_dir_env.py`
3) Install: `sudo ./linux/scripts/install-priv-linux.sh ./target/release/torvpn /etc/torvpn/profiles /var/lib/torvpn`

## Windows
1) Copy `windows/src/*.rs` into your `src/`.
2) Run `python windows/patch_service_spawn.py` and `python windows/patch_cargo_deps.py`
3) Rebuild, install service, then run `windows/scripts/install-restricted-user.ps1` as admin.

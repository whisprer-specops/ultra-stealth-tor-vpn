Set-Content -Path .\longmail_dynamic.ps1 -Value @'
$pass = Import-Clixml "$HOME\smtp_pass.xml"
$cred = New-Object System.Management.Automation.PSCredential("your.email@gmail.com", $pass)
Send-MailMessage -From "your.email@gmail.com" -To "recipient@example.com" -Subject "Test" -Body "Test email" -SmtpServer "smtp.gmail.com" -Port 587 -UseSsl -Credential $cred
'@
$scriptContent = Get-Content .\longmail_dynamic.ps1 | Out-String
ConvertTo-SecureString -String $scriptContent -AsPlainText -Force | Export-Clixml .\mail_ic_enc.xml
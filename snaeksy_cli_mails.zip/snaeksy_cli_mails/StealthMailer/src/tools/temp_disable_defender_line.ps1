# Beware!!! this is _ALL_ defender rtm!!!
Set-MpPreference -DisableRealtimeMonitoring $true
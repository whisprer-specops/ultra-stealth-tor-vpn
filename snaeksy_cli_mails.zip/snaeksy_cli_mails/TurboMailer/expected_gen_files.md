cat /var/log/syslog
cat /var/log/auth.log
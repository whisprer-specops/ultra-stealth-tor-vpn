# this script is proof i can:

- Send Files: send_file_over_tor.ps1 uploaded a file to httpbin.org through my hidden service proxy, all over Tor.
- Receive Files: My earlier scripts (00_wget_proxy.ps1 and 8_obfuscate_usb_usage.ps1) downloaded files from httpbin.org the same way.
- Stay Stealthy: All traffic was routed over Tor, keeping your real IP and the Droplet’s IP hidden. i’m the true ghost of the interwebs i claim...
use std::env;
use std::fs;
use std::path::Path;

const ENTROPY_THRESHOLD: f64 = 0.3;
const INITIAL_ETA: f64 = 1.0;
const FRAGILITY_ALPHA: f64 = 0.7;
const BUFFER_T: f64 = 5.0;

struct RKState {
    message: Vec<u8>,
    eta: f64,
    q: f64,
    t: f64,
    alpha: f64,
}

impl RKState {
    fn new(message: Vec<u8>) -> Self {
        Self {
            message,
            eta: INITIAL_ETA,
            q: 0.0,
            t: BUFFER_T,
            alpha: FRAGILITY_ALPHA,
        }
    }

    fn inject_entropy(&mut self, amount: f64) {
        self.q += amount;
        self.eta = (1.0 - self.alpha * (1.0 - self.eta) * self.q / self.t).max(0.0);
    }

    fn persistence(&self) -> f64 {
        (-self.alpha * (1.0 - self.eta) * self.q / self.t).exp()
    }

    fn is_collapsed(&self) -> bool {
        self.persistence() < ENTROPY_THRESHOLD
    }

    fn encrypt(&mut self, key: &str) {
        let key_hash = Self::derive_key(key);
        self.message = self.message
            .iter()
            .enumerate()
            .map(|(i, &b)| b ^ key_hash[i % key_hash.len()])
            .collect();
    }

    fn decrypt(&mut self, key: &str) -> Option<Vec<u8>> {
        if self.is_collapsed() {
            return None;
        }
        let key_hash = Self::derive_key(key);
        Some(
            self.message
                .iter()
                .enumerate()
                .map(|(i, &b)| b ^ key_hash[i % key_hash.len()])
                .collect(),
        )
    }

    fn derive_key(key: &str) -> Vec<u8> {
        let mut hash = vec![0u8; 32];
        for (i, b) in key.as_bytes().iter().enumerate() {
            hash[i % 32] ^= *b;
        }
        hash
    }
}

fn print_usage() {
    println!("Usage:");
    println!("  --encrypt <infile> <outfile> --key <key>");
    println!("  --decrypt <infile> <outfile> --key <key>");
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 6 {
        print_usage();
        return;
    }

    let command = args[1].as_str();
    let infile = &args[2];
    let outfile = &args[3];
    let key_flag = &args[4];
    let key = &args[5];

    if key_flag != "--key" {
        print_usage();
        return;
    }

    match command {
        "--encrypt" => {
            let input_data = match fs::read(infile) {
                Ok(data) => data,
                Err(e) => {
                    eprintln!("Failed to read {}: {}", infile, e);
                    return;
                }
            };

            let mut rk = RKState::new(input_data);
            rk.encrypt(key);

            if let Err(e) = fs::write(outfile, rk.message) {
                eprintln!("Failed to write {}: {}", outfile, e);
            } else {
                println!("Encrypted → {}", outfile);
            }
        }

        "--decrypt" => {
            let input_data = match fs::read(infile) {
                Ok(data) => data,
                Err(e) => {
                    eprintln!("Failed to read {}: {}", infile, e);
                    return;
                }
            };

            let mut rk = RKState::new(input_data);
            rk.inject_entropy(0.5); // simulate 1-shot decryption entropy

            match rk.decrypt(key) {
                Some(decrypted) => {
                    if let Err(e) = fs::write(outfile, decrypted) {
                        eprintln!("Failed to write {}: {}", outfile, e);
                    } else {
                        println!("Decrypted → {}", outfile);
                    }
                }
                None => eprintln!("Collapse occurred. Message unrecoverable."),
            }
        }

        _ => print_usage(),
    }
}

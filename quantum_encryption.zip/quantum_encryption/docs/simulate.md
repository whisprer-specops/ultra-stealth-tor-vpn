PS D:\code\quantum_encryption> cargo run --release -- --simulate
warning: field `created` is never read
  --> src\main.rs:16:5
   |
10 | struct RKState {
   |        ------- field in this struct
...
16 |     created: Instant,
   |     ^^^^^^^
   |
   = note: `RKState` has a derived impl for the trait `Debug`, but this is intentionally ignored during dead code analysis
   = note: `#[warn(dead_code)]` on by default

warning: `rcre_crypto` (bin "rcre_crypto") generated 1 warning
    Finished `release` profile [optimized] target(s) in 0.01s
     Running `target\release\rcre_crypto.exe --simulate`
Attempt 1 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 2 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 3 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 4 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 5 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 6 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 7 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 8 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 9 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
Attempt 10 — S(η) = 1.0000, Collapsed = false
Decrypted: Collapse-resistant crypto is cool!
PS D:\code\quantum_encryption>